const express = require("express");
const cors = require("cors");

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

// Sample in-memory products. Data resets when the server restarts.
let products = [
  { id: 1, name: "Laptop", category: "Electronics", price: 60000 },
  { id: 2, name: "Headphones", category: "Electronics", price: 2000 },
  { id: 3, name: "Backpack", category: "Accessories", price: 1500 }
];
let nextId = 4;

app.get("/", (req, res) => {
  res.json({ message: "Welcome to Online Shopping Product API" });
});

// GET all products
app.get("/api/products", (req, res) => {
  res.status(200).json(products);
});

// GET one product
app.get("/api/products/:id", (req, res) => {
  const id = Number(req.params.id);
  const product = products.find((item) => item.id === id);
  if (!product) return res.status(404).json({ message: "Product not found" });
  res.status(200).json(product);
});

// POST a product
app.post("/api/products", (req, res) => {
  const { name, category, price } = req.body;
  if (
    typeof name !== "string" || !name.trim() ||
    typeof category !== "string" || !category.trim() ||
    price === "" || price === undefined || !Number.isFinite(Number(price)) || Number(price) < 0
  ) {
    return res.status(400).json({ message: "Provide a valid name, category, and non-negative price." });
  }

  const product = {
    id: nextId++,
    name: name.trim(),
    category: category.trim(),
    price: Number(price)
  };
  products.push(product);
  res.status(201).json({ message: "Product added successfully", product });
});

// PUT update a product
app.put("/api/products/:id", (req, res) => {
  const id = Number(req.params.id);
  const index = products.findIndex((item) => item.id === id);
  if (index === -1) return res.status(404).json({ message: "Product not found" });

  const { name, category, price } = req.body;
  if (
    typeof name !== "string" || !name.trim() ||
    typeof category !== "string" || !category.trim() ||
    price === "" || price === undefined || !Number.isFinite(Number(price)) || Number(price) < 0
  ) {
    return res.status(400).json({ message: "Provide a valid name, category, and non-negative price." });
  }

  products[index] = { id, name: name.trim(), category: category.trim(), price: Number(price) };
  res.status(200).json({ message: "Product updated successfully", product: products[index] });
});

// DELETE a product
app.delete("/api/products/:id", (req, res) => {
  const id = Number(req.params.id);
  const index = products.findIndex((item) => item.id === id);
  if (index === -1) return res.status(404).json({ message: "Product not found" });

  const deleted = products.splice(index, 1)[0];
  res.status(200).json({ message: "Product deleted successfully", product: deleted });
});

// 404 route handler
app.use((req, res) => {
  res.status(404).json({ message: `Route not found: ${req.method} ${req.originalUrl}` });
});

// Central error handler
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ message: "Internal server error" });
});

app.listen(PORT, () => {
  console.log(`Shopping backend running at http://localhost:${PORT}`);
});
