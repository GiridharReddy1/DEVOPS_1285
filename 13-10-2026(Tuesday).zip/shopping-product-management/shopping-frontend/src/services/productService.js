import axios from "axios";

const API = axios.create({
  baseURL: "http://localhost:5000/api"
});

export const getProducts = async () => (await API.get("/products")).data;
export const getProduct = async (id) => (await API.get(`/products/${id}`)).data;
export const addProduct = async (product) => (await API.post("/products", product)).data;
export const updateProduct = async (id, product) => (await API.put(`/products/${id}`, product)).data;
export const deleteProduct = async (id) => (await API.delete(`/products/${id}`)).data;
