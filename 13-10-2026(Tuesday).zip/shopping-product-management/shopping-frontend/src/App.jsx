import { useEffect, useMemo, useState } from "react";
import Header from "./components/Header";
import SearchBar from "./components/SearchBar";
import ProductList from "./components/ProductList";
import ProductForm from "./components/ProductForm";
import ProductDetails from "./components/ProductDetails";
import { getProducts, getProduct, addProduct, updateProduct, deleteProduct } from "./services/productService";

const PAGE_SIZE = 6;

export default function App() {
  const [products, setProducts] = useState([]);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");
  const [minPrice, setMinPrice] = useState("");
  const [maxPrice, setMaxPrice] = useState("");
  const [sort, setSort] = useState("default");
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [editing, setEditing] = useState(null);
  const [selected, setSelected] = useState(null);
  const [cart, setCart] = useState([]);

  const loadProducts = async () => {
    try {
      setLoading(true);
      setError("");
      const data = await getProducts();
      setProducts(data);
    } catch {
      setError("Unable to load products. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { loadProducts(); }, []);

  const categories = useMemo(() => ["All", ...new Set(products.map((p) => p.category))], [products]);

  const filtered = useMemo(() => {
    let result = products.filter((p) =>
      `${p.name} ${p.category}`.toLowerCase().includes(search.toLowerCase())
    );
    if (category !== "All") result = result.filter((p) => p.category === category);
    if (minPrice !== "") result = result.filter((p) => Number(p.price) >= Number(minPrice));
    if (maxPrice !== "") result = result.filter((p) => Number(p.price) <= Number(maxPrice));
    if (sort === "low") result.sort((a, b) => a.price - b.price);
    if (sort === "high") result.sort((a, b) => b.price - a.price);
    if (sort === "name") result.sort((a, b) => a.name.localeCompare(b.name));
    return result;
  }, [products, search, category, minPrice, maxPrice, sort]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const visible = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  const saveProduct = async (product) => {
    try {
      setSaving(true);
      setError("");
      if (editing) await updateProduct(editing.id, product);
      else await addProduct(product);
      setEditing(null);
      await loadProducts();
    } catch (err) {
      setError(err.response?.data?.message || "Unable to save product. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  const removeProduct = async (id) => {
    if (!window.confirm("Are you sure you want to delete this product?")) return;
    try {
      await deleteProduct(id);
      setProducts((current) => current.filter((p) => p.id !== id));
      if (selected?.id === id) setSelected(null);
    } catch (err) {
      setError(err.response?.data?.message || "Unable to delete product.");
    }
  };

  const showDetails = async (id) => {
    try {
      setSelected(await getProduct(id));
    } catch {
      setError("Unable to load product details.");
    }
  };

  const addToCart = (product) => setCart((current) => [...current, product]);

  return (
    <div>
      <Header cartCount={cart.length} />
      <main className="container">
        <section className="hero">
          <div><p className="eyebrow">ONLINE STORE · PRODUCT DASHBOARD</p><h1>Find your next<br /><span>favorite thing.</span></h1><p className="hero-copy">Browse, search and manage your store products in one place.</p></div>
          <div className="hero-icon">🛍️</div>
        </section>

        <section id="products" className="section-heading">
          <div><p className="eyebrow">THE COLLECTION</p><h2>Products <span className="count">{filtered.length}</span></h2></div>
          <SearchBar value={search} onChange={(v) => { setSearch(v); setPage(1); }} />
        </section>

        <section className="filters">
          <label>Category
            <select value={category} onChange={(e) => { setCategory(e.target.value); setPage(1); }}>
              {categories.map((c) => <option key={c}>{c}</option>)}
            </select>
          </label>
          <label>Min price
            <input type="number" min="0" placeholder="₹ Min" value={minPrice} onChange={(e) => { setMinPrice(e.target.value); setPage(1); }} />
          </label>
          <label>Max price
            <input type="number" min="0" placeholder="₹ Max" value={maxPrice} onChange={(e) => { setMaxPrice(e.target.value); setPage(1); }} />
          </label>
          <label>Sort by
            <select value={sort} onChange={(e) => setSort(e.target.value)}>
              <option value="default">Default</option><option value="low">Price: low to high</option><option value="high">Price: high to low</option><option value="name">Name</option>
            </select>
          </label>
        </section>

        {error && <div className="alert">{error} <button onClick={loadProducts}>Retry</button></div>}

        <div className="content-layout">
          <section className="listing">
            {loading ? <div className="empty">Loading products...</div> :
              <ProductList products={visible} onEdit={setEditing} onDelete={removeProduct} onDetails={showDetails} onAddToCart={addToCart} />}
            {!loading && filtered.length > PAGE_SIZE && <div className="pagination">
              <button disabled={page === 1} onClick={() => setPage(page - 1)}>← Previous</button>
              <span>Page {page} of {totalPages}</span>
              <button disabled={page === totalPages} onClick={() => setPage(page + 1)}>Next →</button>
            </div>}
          </section>
          <aside><ProductForm editing={editing} onSave={saveProduct} onCancel={() => setEditing(null)} saving={saving} />
            <div className="cart-summary"><strong>Shopping cart</strong><span>{cart.length} item(s)</span><p>{cart.length ? `Subtotal: ₹${cart.reduce((sum, p) => sum + Number(p.price), 0).toLocaleString("en-IN")}` : "Your cart is empty."}</p></div>
          </aside>
        </div>
        <footer>ShopEase · Product Management Demo</footer>
      </main>
      <ProductDetails product={selected} onClose={() => setSelected(null)} />
    </div>
  );
}
