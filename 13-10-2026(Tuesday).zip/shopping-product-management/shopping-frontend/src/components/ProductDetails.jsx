export default function ProductDetails({ product, onClose }) {
  if (!product) return null;
  return (
    <div className="modal-backdrop" onClick={onClose}>
      <section className="details-modal" onClick={(e) => e.stopPropagation()}>
        <button className="modal-close" onClick={onClose}>×</button>
        <div className="product-art large">🛍️</div>
        <span className="category">{product.category}</span>
        <h2>{product.name}</h2>
        <p className="price">₹{Number(product.price).toLocaleString("en-IN")}</p>
        <p className="muted">Product ID: {product.id}</p>
      </section>
    </div>
  );
}
