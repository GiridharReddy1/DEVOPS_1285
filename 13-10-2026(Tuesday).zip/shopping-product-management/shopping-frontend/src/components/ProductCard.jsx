export default function ProductCard({ product, onEdit, onDelete, onDetails, onAddToCart }) {
  const symbol = product.category.toLowerCase() === "electronics" ? "💻" : "🎒";
  return (
    <article className="product-card">
      <div className="product-art">{symbol}</div>
      <div className="product-info">
        <span className="category">{product.category}</span>
        <h3>{product.name}</h3>
        <p className="price">₹{Number(product.price).toLocaleString("en-IN")}</p>
        <div className="card-actions">
          <button className="primary small" onClick={() => onAddToCart(product)}>Add to cart</button>
          <button className="light small" onClick={() => onDetails(product.id)}>Details</button>
        </div>
        <div className="admin-actions">
          <button onClick={() => onEdit(product)}>Edit</button>
          <button className="delete" onClick={() => onDelete(product.id)}>Delete</button>
        </div>
      </div>
    </article>
  );
}
