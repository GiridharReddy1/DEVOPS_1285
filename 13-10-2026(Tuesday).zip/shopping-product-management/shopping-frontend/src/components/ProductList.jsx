import ProductCard from "./ProductCard";

export default function ProductList({ products, ...actions }) {
  if (!products.length) return <div className="empty">No products match your search.</div>;
  return (
    <div className="product-grid">
      {products.map((product) => <ProductCard key={product.id} product={product} {...actions} />)}
    </div>
  );
}
