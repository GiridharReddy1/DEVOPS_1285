import { useEffect, useState } from "react";

const blank = { name: "", category: "", price: "" };

export default function ProductForm({ editing, onSave, onCancel, saving }) {
  const [form, setForm] = useState(blank);
  useEffect(() => {
    setForm(editing ? { name: editing.name, category: editing.category, price: editing.price } : blank);
  }, [editing]);

  const submit = (e) => {
    e.preventDefault();
    onSave({ ...form, price: Number(form.price) });
  };

  return (
    <form className="form-card" onSubmit={submit}>
      <h2>{editing ? "Update product" : "Add a product"}</h2>
      <label>Product name
        <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Smart Watch" />
      </label>
      <label>Category
        <input required value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} placeholder="e.g. Electronics" />
      </label>
      <label>Price (₹)
        <input required min="0" type="number" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} placeholder="Enter price" />
      </label>
      <div className="form-actions">
        <button className="primary" disabled={saving}>{saving ? "Saving..." : editing ? "Save changes" : "Add product"}</button>
        {editing && <button type="button" className="light" onClick={onCancel}>Cancel</button>}
      </div>
    </form>
  );
}
