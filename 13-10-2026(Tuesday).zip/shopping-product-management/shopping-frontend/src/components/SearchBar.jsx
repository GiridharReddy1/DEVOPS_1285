export default function SearchBar({ value, onChange }) {
  return (
    <label className="search-wrap">
      <span>⌕</span>
      <input value={value} onChange={(e) => onChange(e.target.value)} placeholder="Search products by name or category..." />
    </label>
  );
}
