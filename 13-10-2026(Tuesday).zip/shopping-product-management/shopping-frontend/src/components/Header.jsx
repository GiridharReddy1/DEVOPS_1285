export default function Header({ cartCount }) {
  return (
    <header className="header">
      <a className="brand" href="/">ShopEase<span>.</span></a>
      <nav><a href="#products">Products</a><span className="cart">🛒 Cart ({cartCount})</span></nav>
    </header>
  );
}
