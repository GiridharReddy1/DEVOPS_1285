# Online Shopping Product Management

This project follows the uploaded Assignment 10.1.2 PDF.

## Folder structure

- `shopping-backend` — Node.js + Express REST API on port 5000
- `shopping-frontend` — React + Vite frontend on port 5173

## 1. Start the backend

Open VS Code terminal in `shopping-backend`:

```bash
npm install
npm run dev
```

Backend URL: `http://localhost:5000`

## 2. Start the frontend

Open a **second terminal** in `shopping-frontend`:

```bash
npm install
npm run dev
```

Open the URL printed by Vite (normally `http://localhost:5173`).

## API endpoints

| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/products` | List all products |
| GET | `/api/products/:id` | Get one product |
| POST | `/api/products` | Add a product |
| PUT | `/api/products/:id` | Update a product |
| DELETE | `/api/products/:id` | Delete a product |

Example POST/PUT JSON:

```json
{
  "name": "Smart Watch",
  "category": "Electronics",
  "price": 3500
}
```

## Features

- React communicates with Express using Axios.
- Separate API service file.
- Product listing, details, searching, adding, editing and deleting.
- Loading and error states, including retry.
- Empty search-result message.
- Category and price filters.
- Product sorting and pagination.
- Simple shopping cart with item count and subtotal.
- Backend input validation, CORS, JSON parsing and 404/error handling.

## Notes

The backend uses an in-memory array for sample data. Products reset when the backend restarts. This is a learning assignment and does not include a database or authentication.
