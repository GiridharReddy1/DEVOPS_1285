import { useMemo, useState } from "react";
import Restaurant from "./components/Restaurant.jsx";
import FoodList from "./components/FoodList.jsx";
import Order from "./components/Order.jsx";
import OrderSummary from "./components/OrderSummary.jsx";
import { restaurant, foodItems } from "./data/foodData.js";

export default function App() {
  const [foods] = useState(foodItems);
  const [orderItems, setOrderItems] = useState([]);
  const [category, setCategory] = useState("All");
  const [search, setSearch] = useState("");
  const [coupon, setCoupon] = useState("");
  const [discountRate, setDiscountRate] = useState(0);
  const [couponMessage, setCouponMessage] = useState("");
  const [notice, setNotice] = useState("");

  const categories = ["All", ...new Set(foods.map((food) => food.category))];
  const filteredFoods = useMemo(() => foods.filter((food) =>
    (category === "All" || food.category === category) &&
    food.name.toLowerCase().includes(search.toLowerCase())
  ), [foods, category, search]);

  const subtotal = orderItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const discount = subtotal * discountRate;
  const taxableAmount = Math.max(0, subtotal - discount);
  const tax = taxableAmount * 0.05;
  const delivery = subtotal === 0 || subtotal >= 499 ? 0 : 40;
  const total = taxableAmount + tax + delivery;

  const addToOrder = (food) => {
    setOrderItems((current) => {
      const existing = current.find((item) => item.id === food.id);
      if (existing) return current.map((item) => item.id === food.id ? { ...item, quantity: item.quantity + 1 } : item);
      return [...current, { ...food, quantity: 1 }];
    });
    setNotice(`${food.name} added to your order.`);
  };

  const increase = (id) => setOrderItems((items) => items.map((item) => item.id === id ? { ...item, quantity: item.quantity + 1 } : item));
  const decrease = (id) => setOrderItems((items) => items.map((item) => item.id === id ? { ...item, quantity: item.quantity - 1 } : item).filter((item) => item.quantity > 0));
  const remove = (id) => setOrderItems((items) => items.filter((item) => item.id !== id));

  const applyCoupon = () => {
    if (coupon.trim().toUpperCase() === "SAVE10") {
      setDiscountRate(0.10);
      setCouponMessage("Coupon applied! You saved 10%.");
    } else {
      setDiscountRate(0);
      setCouponMessage("Invalid coupon. Try SAVE10.");
    }
  };

  const placeOrder = () => {
    if (!orderItems.length) return;
    setNotice(`Order placed successfully! Your payable amount was ₹${total.toFixed(2)}.`);
    setOrderItems([]);
    setCoupon("");
    setDiscountRate(0);
    setCouponMessage("");
  };

  return (
    <div className="app-shell">
      <header className="topbar"><a className="brand" href="#">spice<span>route</span><i>.</i></a><span className="topbar-note">GOOD FOOD. GOOD MOOD.</span><a className="cart-link" href="#your-order">🛒 Your order ({orderItems.length})</a></header>
      <main className="container">
        <Restaurant {...restaurant} />
        <div className="content-heading"><div><span className="eyebrow">MADE FRESH FOR YOU</span><h2>Explore the menu</h2></div><label className="search-box">⌕ <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search dishes..." /></label></div>
        <nav className="filters" aria-label="Food categories">{categories.map((name) => <button key={name} className={category === name ? "active" : ""} onClick={() => setCategory(name)}>{name}</button>)}</nav>
        {notice && <div className="notice" role="status">{notice}<button onClick={() => setNotice("")} aria-label="Dismiss message">×</button></div>}
        <div className="main-layout">
          <section className="menu-section"><FoodList foods={filteredFoods} orderItems={orderItems} onAdd={addToOrder} /></section>
          <aside className="order-panel" id="your-order"><div className="order-heading"><div><span className="eyebrow">YOUR SELECTION</span><h2>Order summary</h2></div><span className="item-count">{orderItems.reduce((n, item) => n + item.quantity, 0)} items</span></div>
            <Order items={orderItems} onIncrease={increase} onDecrease={decrease} onRemove={remove} />
            {orderItems.length > 0 && <>
              <OrderSummary subtotal={subtotal} discount={discount} tax={tax} delivery={delivery} total={total} coupon={coupon} setCoupon={setCoupon} applyCoupon={applyCoupon} couponMessage={couponMessage} />
              <button className="place-order" onClick={placeOrder}>Place order · ₹{total.toFixed(2)}</button>
            </>}
          </aside>
        </div>
      </main>
      <footer>Made with care at Spice Route <span>·</span> React Props & State Lab</footer>
    </div>
  );
}
