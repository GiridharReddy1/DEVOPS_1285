export default function OrderSummary({ subtotal, discount, tax, delivery, total, coupon, setCoupon, applyCoupon, couponMessage }) {
  return (
    <section className="summary">
      <h3>Bill details</h3>
      <div className="coupon-row">
        <input value={coupon} onChange={(e) => setCoupon(e.target.value)} placeholder="Enter coupon (SAVE10)" aria-label="Coupon code" />
        <button onClick={applyCoupon}>Apply</button>
      </div>
      {couponMessage && <p className="coupon-message">{couponMessage}</p>}
      <div className="bill-row"><span>Item total</span><span>₹{subtotal.toFixed(2)}</span></div>
      <div className="bill-row"><span>Discount</span><span>− ₹{discount.toFixed(2)}</span></div>
      <div className="bill-row"><span>Tax (5%)</span><span>₹{tax.toFixed(2)}</span></div>
      <div className="bill-row"><span>Delivery</span><span>{delivery === 0 ? "FREE" : `₹${delivery.toFixed(2)}`}</span></div>
      <div className="bill-total"><b>To pay</b><strong>₹{total.toFixed(2)}</strong></div>
    </section>
  );
}
