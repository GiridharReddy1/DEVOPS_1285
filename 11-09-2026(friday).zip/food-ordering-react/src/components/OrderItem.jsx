export default function OrderItem({ item, onIncrease, onDecrease, onRemove }) {
  return (
    <div className="order-item">
      <div className="order-item-info">
        <b>{item.name}</b>
        <small>₹{item.price} each</small>
      </div>
      <div className="quantity-control">
        <button aria-label={`Decrease ${item.name}`} onClick={() => onDecrease(item.id)}>−</button>
        <span>{item.quantity}</span>
        <button aria-label={`Increase ${item.name}`} onClick={() => onIncrease(item.id)}>+</button>
      </div>
      <b className="line-total">₹{item.price * item.quantity}</b>
      <button className="remove-button" aria-label={`Remove ${item.name}`} onClick={() => onRemove(item.id)}>×</button>
    </div>
  );
}
