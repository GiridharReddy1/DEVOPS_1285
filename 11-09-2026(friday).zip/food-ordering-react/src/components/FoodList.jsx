import FoodItem from "./FoodItem.jsx";

export default function FoodList({ foods, orderItems, onAdd }) {
  return (
    <div className="food-grid">
      {foods.map((food) => (
        <FoodItem
          key={food.id}
          food={food}
          quantity={orderItems.find((item) => item.id === food.id)?.quantity || 0}
          onAdd={onAdd}
        />
      ))}
    </div>
  );
}
