import OrderItem from "./OrderItem.jsx";

export default function Order({ items, onIncrease, onDecrease, onRemove }) {
  if (items.length === 0) {
    return <div className="empty-order"><span>🛒</span><b>Your order is empty</b><p>Add delicious food from the menu to get started.</p></div>;
  }

  return (
    <div className="order-list">
      {items.map((item) => (
        <OrderItem key={item.id} item={item} onIncrease={onIncrease} onDecrease={onDecrease} onRemove={onRemove} />
      ))}
    </div>
  );
}
