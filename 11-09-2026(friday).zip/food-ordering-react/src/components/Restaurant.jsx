export default function Restaurant({ name, tagline, rating, deliveryTime }) {
  return (
    <section className="restaurant-banner">
      <div>
        <span className="eyebrow">WELCOME TO</span>
        <h1>{name}</h1>
        <p>{tagline}</p>
        <div className="restaurant-meta"><span>★ {rating}</span><span>◷ {deliveryTime}</span><span>Free delivery above ₹499</span></div>
      </div>
      <div className="restaurant-emoji" aria-hidden="true">🍽️</div>
    </section>
  );
}
