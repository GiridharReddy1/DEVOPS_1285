export default function FoodItem({ food, onAdd, quantity }) {
  return (
    <article className="food-card">
      <img className="food-image" src={food.image} alt={food.name} loading="lazy"
        onError={(event) => { event.currentTarget.style.display = "none"; }} />
      <div className="food-card-body">
        <span className="category-label">{food.category}</span>
        <h3>{food.name}</h3>
        <p>{food.description}</p>
        <div className="food-card-bottom">
          <strong>₹{food.price}</strong>
          <button onClick={() => onAdd(food)}>{quantity > 0 ? `Add more (${quantity}) +` : "Add to order +"}</button>
        </div>
      </div>
    </article>
  );
}
