export const restaurant = {
  name: "Spice Route",
  tagline: "Fresh flavours, delivered with love",
  rating: "4.8",
  deliveryTime: "25–35 min"
};

export const foodItems = [
  { id: 1, name: "Paneer Tikka", category: "Starters", price: 220, image: "https://images.unsplash.com/photo-1567188040759-fb8a883dc6d8?w=700", description: "Smoky paneer cubes with spices" },
  { id: 2, name: "Veg Spring Rolls", category: "Starters", price: 160, image: "https://images.unsplash.com/photo-1544025162-d76694265947?w=700", description: "Crispy rolls with fresh vegetables" },
  { id: 3, name: "Chicken Biryani", category: "Main Course", price: 280, image: "https://images.unsplash.com/photo-1563379091339-03246963d96c?w=700", description: "Aromatic basmati rice and spices" },
  { id: 4, name: "Veg Fried Rice", category: "Main Course", price: 190, image: "https://images.unsplash.com/photo-1603133872878-684f208fb84b?w=700", description: "Wok-tossed rice with vegetables" },
  { id: 5, name: "Chocolate Brownie", category: "Desserts", price: 140, image: "https://images.unsplash.com/photo-1606313564200-e75d5e30476c?w=700", description: "Warm chocolate brownie" },
  { id: 6, name: "Gulab Jamun", category: "Desserts", price: 100, image: "https://images.unsplash.com/photo-1666190092159-4b7c7f6a3d77?w=700", description: "Soft milk dumplings in syrup" },
  { id: 7, name: "Fresh Lime Soda", category: "Drinks", price: 80, image: "https://images.unsplash.com/photo-1513558161293-cdaf765edfd4?w=700", description: "Refreshing sweet and salted lime" },
  { id: 8, name: "Cold Coffee", category: "Drinks", price: 120, image: "https://images.unsplash.com/photo-1461023058943-07fcbe16d735?w=700", description: "Chilled creamy coffee" }
];
