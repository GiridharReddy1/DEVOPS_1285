# Week 6.2 – Online Food Ordering and Delivery System

React + Vite lab project demonstrating component reuse, props, `useState`, conditional rendering, and dynamic order calculations.

## Components included

- `Restaurant` – restaurant name and information via props.
- `FoodList` – renders the available food items.
- `FoodItem` – displays food name, category, price and image using props.
- `Order` – displays selected items or an empty-order message.
- `OrderItem` – quantity controls and remove action.
- `OrderSummary` – subtotal, coupon discount, tax, delivery fee and final payable amount.

## Run the project

1. Install Node.js (LTS) if it is not already installed.
2. Extract the ZIP and open this folder in VS Code.
3. Open the terminal in the project folder and run:

```bash
npm install
npm run dev
```

4. Open the local URL printed by Vite, usually `http://localhost:5173`.

## Features

- Add food items to an order; adding the same item increases its quantity instead of creating a duplicate row.
- Increase, decrease or remove selected food.
- Search dishes by name and filter by category.
- Empty-order conditional rendering.
- Dynamic subtotal, 5% tax and delivery charge (free for orders of ₹499 or more).
- Demo coupon `SAVE10` applies a 10% discount.
- Responsive layout for desktop and mobile.

## Notes

Food data is stored in `src/data/foodData.js`. The project is a frontend React lab demo and does not require a backend or database. Food photos load from Unsplash and therefore require an internet connection; the app's ordering features work independently of the photos.
