# CarePoint – Hospital Appointment Management System

A React + Vite frontend assignment demonstrating React Router, dynamic routes, `useParams()`, `useState()`, `useEffect()`, loading states, cleanup, and appointment management.

## Requirements
- Node.js (LTS recommended)
- Visual Studio Code

## Run the project
1. Extract `hospital-appointment-app.zip`.
2. Open the extracted `hospital-appointment-app` folder in VS Code.
3. Open the VS Code terminal (**Terminal → New Terminal**).
4. Install dependencies:

   ```bash
   npm install
   ```

5. Start the development server:

   ```bash
   npm run dev
   ```

6. Open the URL printed in the terminal (usually `http://localhost:5173`).

## Routes
| URL | Page |
| --- | --- |
| `/` | Home |
| `/doctors` | Doctors list |
| `/doctors/1` | Dr. Ananya Rao |
| `/doctors/2` | Dr. Rahul Mehta |
| `/doctors/3` | Dr. Priya Sharma |
| `/appointments` | Appointment list |
| `/profile` | Patient profile |
| Any unknown URL | 404 Not Found |

## Assignment requirements covered
- Navigation with `NavLink` and client-side routing.
- `useParams()` reads the doctor ID from `/doctors/:id`.
- `useEffect()` loads doctor details when the component mounts or the ID changes.
- Loading indicator while doctor data is loaded.
- Cleanup function clears the pending timer and resets component state.
- `useState()` manages doctor data, loading, booking form, and confirmation.
- At least three doctors stored in an array.
- Book and cancel appointment actions.
- Appointment count in the navigation bar.
- Invalid doctor IDs display **Doctor Not Found**.
- Unknown routes display a 404 page.
- Appointment state is shared with React Context so it is available on multiple pages.

## Try these checks
1. Open `/doctors`, then select a doctor.
2. Open `/doctors/1`, `/doctors/2`, and `/doctors/3` to see different doctor details.
3. Enter `/doctors/99` to test **Doctor Not Found**.
4. Book an appointment and open **Appointments**.
5. Cancel the appointment and check the navigation count.
6. Open `/some-unknown-page` to test the 404 route.

## Notes
- This is a frontend assignment demo. Doctor data and appointments are stored in browser memory; they are not connected to a hospital database or real booking service.
- The date field prevents selecting a past date.
