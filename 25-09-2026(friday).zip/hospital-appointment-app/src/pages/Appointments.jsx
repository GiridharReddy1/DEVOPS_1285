import { Link } from 'react-router-dom'
import { useAppointments } from '../context/AppointmentContext'

export default function Appointments() {
  const { appointments, cancelAppointment } = useAppointments()
  return (
    <main className="page-shell">
      <div className="page-heading"><span className="eyebrow">YOUR VISITS</span><h1>Appointments</h1><p>View and manage your scheduled consultations.</p></div>
      {appointments.length === 0 ? <div className="empty-state"><div className="empty-symbol">＋</div><h2>No appointments yet</h2><p>Your booked appointments will appear here.</p><Link to="/doctors" className="primary-button">Find a doctor</Link></div> :
        <div className="appointment-list">{appointments.map((item) => <article className="appointment-card" key={item.id}><div className="appointment-date"><b>{new Date(`${item.date}T00:00:00`).toLocaleDateString('en-US', { day: '2-digit' })}</b><span>{new Date(`${item.date}T00:00:00`).toLocaleDateString('en-US', { month: 'short' })}</span></div><div className="appointment-info"><span className="status-pill">Confirmed</span><h3>{item.doctorName}</h3><p>{item.specialty} · Patient: {item.patientName}</p><small>{item.date} at {item.time}</small></div><button className="cancel-button" onClick={() => cancelAppointment(item.id)}>Cancel appointment</button></article>)}</div>}
    </main>
  )
}