import { useMemo, useState } from 'react'
import DoctorCard from '../components/DoctorCard'
import { doctors } from '../data/doctors'

export default function Doctors() {
  const [search, setSearch] = useState('')
  const filteredDoctors = useMemo(() => doctors.filter((doctor) =>
    `${doctor.name} ${doctor.specialty}`.toLowerCase().includes(search.toLowerCase())
  ), [search])

  return (
    <main className="page-shell">
      <div className="page-heading"><span className="eyebrow">OUR MEDICAL TEAM</span><h1>Meet our doctors</h1><p>Browse our specialists and choose the care that is right for you.</p></div>
      <div className="search-wrap"><span>⌕</span><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search by doctor or specialty..." /></div>
      {filteredDoctors.length ? <div className="doctor-grid">{filteredDoctors.map((doctor) => <DoctorCard key={doctor.id} doctor={doctor} />)}</div> : <div className="empty-state"><h3>No doctors found</h3><p>Try searching with another name or specialty.</p></div>}
    </main>
  )
}