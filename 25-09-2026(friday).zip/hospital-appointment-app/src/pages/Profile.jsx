import { useAppointments } from '../context/AppointmentContext'
import { Link } from 'react-router-dom'

export default function Profile() {
  const { appointments } = useAppointments()
  return (
    <main className="page-shell">
      <div className="page-heading"><span className="eyebrow">PERSONAL SPACE</span><h1>Patient profile</h1><p>A quick overview of your CarePoint activity.</p></div>
      <section className="profile-card"><div className="profile-avatar">P</div><div><span className="verified">Patient account</span><h2>Welcome, Patient</h2><p className="muted">Your health journey, all in one place.</p></div></section>
      <div className="profile-stats"><div className="stat-card"><span>Total appointments</span><strong>{appointments.length}</strong></div><div className="stat-card"><span>Upcoming visits</span><strong>{appointments.filter((a) => a.date >= new Date().toISOString().slice(0, 10)).length}</strong></div></div>
      <Link to="/appointments" className="primary-button">Manage appointments →</Link>
    </main>
  )
}