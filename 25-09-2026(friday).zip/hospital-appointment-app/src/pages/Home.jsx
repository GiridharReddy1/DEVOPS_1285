import { Link } from 'react-router-dom'
import { doctors } from '../data/doctors'
import DoctorCard from '../components/DoctorCard'

export default function Home() {
  return (
    <main>
      <section className="hero">
        <div className="hero-copy">
          <span className="eyebrow"><span className="pulse-dot" /> YOUR HEALTH, OUR PRIORITY</span>
          <h1>Care that puts<br /><span>you first.</span></h1>
          <p>Find trusted specialists and book your hospital appointment in just a few simple steps.</p>
          <div className="hero-actions">
            <Link to="/doctors" className="primary-button">Find a doctor <span>→</span></Link>
            <Link to="/appointments" className="text-link">View appointments</Link>
          </div>
          <div className="hero-stats">
            <div><strong>3+</strong><span>Specialists</span></div>
            <div><strong>10k+</strong><span>Happy patients</span></div>
            <div><strong>24/7</strong><span>Care support</span></div>
          </div>
        </div>
        <div className="hero-art">
          <div className="hero-circle"><div className="cross">✚</div></div>
          <div className="floating-note note-one"><span className="note-icon">✓</span><div><b>Easy booking</b><small>Appointments made simple</small></div></div>
          <div className="floating-note note-two"><span className="note-icon blue-note">♡</span><div><b>Trusted care</b><small>Doctors you can count on</small></div></div>
          <div className="art-caption">A healthier tomorrow starts today.</div>
        </div>
      </section>
      <section className="section">
        <div className="section-heading">
          <div><span className="eyebrow">MEET OUR SPECIALISTS</span><h2>Find the right doctor</h2><p>Experienced professionals, here to help you feel your best.</p></div>
          <Link to="/doctors" className="text-link">View all doctors →</Link>
        </div>
        <div className="doctor-grid">{doctors.map((doctor) => <DoctorCard key={doctor.id} doctor={doctor} />)}</div>
      </section>
      <section className="care-strip"><div className="care-icon">✚</div><div><h3>Small steps make a big difference.</h3><p>Schedule a consultation and take charge of your wellbeing.</p></div><Link to="/doctors" className="light-button">Book a visit →</Link></section>
    </main>
  )
}