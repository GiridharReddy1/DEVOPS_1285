import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { doctors } from '../data/doctors'
import { useAppointments } from '../context/AppointmentContext'

export default function DoctorDetails() {
  const { id } = useParams()
  const { bookAppointment } = useAppointments()
  const [doctor, setDoctor] = useState(null)
  const [loading, setLoading] = useState(true)
  const [booked, setBooked] = useState(false)
  const [patientName, setPatientName] = useState('')
  const [date, setDate] = useState('')
  const [time, setTime] = useState('10:00')

  useEffect(() => {
    let active = true
    setLoading(true)
    setBooked(false)
    setPatientName('')
    setDate('')
    const timer = setTimeout(() => {
      if (active) {
        setDoctor(doctors.find((item) => item.id === id) || null)
        setLoading(false)
      }
    }, 450)
    return () => {
      active = false
      clearTimeout(timer)
      setDoctor(null)
      setBooked(false)
    }
  }, [id])

  const submitAppointment = (event) => {
    event.preventDefault()
    if (!doctor || !patientName.trim() || !date) return
    bookAppointment({ doctorId: doctor.id, doctorName: doctor.name, specialty: doctor.specialty, patientName: patientName.trim(), date, time })
    setBooked(true)
  }

  if (loading) return <main className="page-shell"><div className="loading"><span className="spinner" />Loading doctor information...</div></main>
  if (!doctor) return <main className="page-shell"><div className="empty-state"><div className="empty-symbol">?</div><h2>Doctor Not Found</h2><p>The doctor ID you entered does not match our records.</p><Link to="/doctors" className="primary-button">Back to doctors</Link></div></main>

  return (
    <main className="page-shell">
      <Link to="/doctors" className="back-link">← Back to doctors</Link>
      <section className="detail-layout">
        <div className="detail-card">
          <div className={`avatar large ${doctor.color}`}>{doctor.initials}</div>
          <span className="verified">✓ Verified specialist</span>
          <h1>{doctor.name}</h1><p className="specialty">{doctor.specialty}</p>
          <div className="detail-rating">★ {doctor.rating} <span>Patient rating</span></div>
          <div className="detail-facts">
            <div><small>Experience</small><b>{doctor.experience}</b></div>
            <div><small>Consultation fee</small><b>₹{doctor.fee}</b></div>
          </div>
          <h3>About the doctor</h3><p className="muted about">{doctor.about}</p>
          <h3>Qualifications</h3><p className="muted">{doctor.qualification}</p>
          <h3>Availability</h3><p className="muted">{doctor.availability}</p>
        </div>
        <aside className="booking-card">
          <span className="eyebrow">SCHEDULE A VISIT</span><h2>Book appointment</h2>
          {booked ? <div className="success-panel"><div className="success-check">✓</div><h3>Appointment Booked Successfully</h3><p>Your appointment with {doctor.name} has been added.</p><Link to="/appointments" className="primary-button">View appointments</Link><button className="outline-button" onClick={() => setBooked(false)}>Book another</button></div> :
            <form onSubmit={submitAppointment} className="booking-form">
              <label>Patient name<input required value={patientName} onChange={(e) => setPatientName(e.target.value)} placeholder="Enter patient name" /></label>
              <label>Appointment date<input required type="date" min={new Date().toISOString().split('T')[0]} value={date} onChange={(e) => setDate(e.target.value)} /></label>
              <label>Preferred time<select value={time} onChange={(e) => setTime(e.target.value)}><option value="09:00">09:00 AM</option><option value="10:00">10:00 AM</option><option value="11:00">11:00 AM</option><option value="12:00">12:00 PM</option><option value="14:00">02:00 PM</option><option value="15:00">03:00 PM</option></select></label>
              <div className="fee-row"><span>Consultation fee</span><strong>₹{doctor.fee}</strong></div>
              <button className="primary-button full-button" type="submit">Confirm appointment →</button>
              <p className="form-note">You can cancel your appointment anytime.</p>
            </form>}
        </aside>
      </section>
    </main>
  )
}