import { Link } from 'react-router-dom'

export default function NotFound() {
  return <main className="page-shell"><div className="empty-state"><div className="notfound-code">404</div><h2>Page not found</h2><p>Sorry, the page you are looking for does not exist.</p><Link to="/" className="primary-button">Return home</Link></div></main>
}