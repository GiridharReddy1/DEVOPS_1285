import { Route, Routes } from 'react-router-dom'
import Navbar from './components/Navbar'
import { AppointmentProvider } from './context/AppointmentContext'
import Home from './pages/Home'
import Doctors from './pages/Doctors'
import DoctorDetails from './pages/DoctorDetails'
import Appointments from './pages/Appointments'
import Profile from './pages/Profile'
import NotFound from './pages/NotFound'

export default function App() {
  return (
    <AppointmentProvider>
      <div className="app">
        <Navbar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/doctors" element={<Doctors />} />
          <Route path="/doctors/:id" element={<DoctorDetails />} />
          <Route path="/appointments" element={<Appointments />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
        <footer className="footer"><span>✚ CarePoint</span><span>Thoughtful care. Better health.</span><span>© 2026 CarePoint</span></footer>
      </div>
    </AppointmentProvider>
  )
}