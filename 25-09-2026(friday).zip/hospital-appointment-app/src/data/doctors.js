export const doctors = [
  {
    id: '1',
    name: 'Dr. Ananya Rao',
    specialty: 'Cardiologist',
    experience: '12 years',
    qualification: 'MBBS, MD (Cardiology)',
    availability: 'Mon - Fri, 9:00 AM - 2:00 PM',
    fee: 700,
    rating: '4.9',
    initials: 'AR',
    color: 'blue',
    about: 'Dr. Ananya Rao focuses on preventive heart care, diagnosis, and long-term cardiac wellness.'
  },
  {
    id: '2',
    name: 'Dr. Rahul Mehta',
    specialty: 'Dermatologist',
    experience: '9 years',
    qualification: 'MBBS, MD (Dermatology)',
    availability: 'Mon - Sat, 10:00 AM - 4:00 PM',
    fee: 550,
    rating: '4.8',
    initials: 'RM',
    color: 'green',
    about: 'Dr. Rahul Mehta provides care for common skin conditions and supports healthy skin routines.'
  },
  {
    id: '3',
    name: 'Dr. Priya Sharma',
    specialty: 'Pediatrician',
    experience: '11 years',
    qualification: 'MBBS, MD (Pediatrics)',
    availability: 'Tue - Sat, 9:30 AM - 3:30 PM',
    fee: 600,
    rating: '4.9',
    initials: 'PS',
    color: 'purple',
    about: 'Dr. Priya Sharma cares for children through routine checkups, development guidance, and family support.'
  }
]