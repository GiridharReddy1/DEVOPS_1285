import { Link } from 'react-router-dom'

export default function DoctorCard({ doctor }) {
  return (
    <article className="doctor-card">
      <div className={`avatar ${doctor.color}`}>{doctor.initials}</div>
      <div className="doctor-card-body">
        <div className="rating">★ {doctor.rating} <span>· {doctor.experience} experience</span></div>
        <h3>{doctor.name}</h3>
        <p className="specialty">{doctor.specialty}</p>
        <p className="muted">{doctor.qualification}</p>
        <div className="card-bottom">
          <strong>₹{doctor.fee}<small> / visit</small></strong>
          <Link className="small-button" to={`/doctors/${doctor.id}`}>View details <span>→</span></Link>
        </div>
      </div>
    </article>
  )
}