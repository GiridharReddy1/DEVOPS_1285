import { NavLink } from 'react-router-dom'
import { useAppointments } from '../context/AppointmentContext'

export default function Navbar() {
  const { appointments } = useAppointments()
  return (
    <header className="topbar">
      <NavLink to="/" className="brand">
        <span className="brand-mark">✚</span>
        <span>Care<span className="brand-accent">Point</span></span>
      </NavLink>
      <nav className="nav-links">
        <NavLink to="/" end>Home</NavLink>
        <NavLink to="/doctors">Doctors</NavLink>
        <NavLink to="/appointments">Appointments <span className="count">{appointments.length}</span></NavLink>
        <NavLink to="/profile">Profile</NavLink>
      </nav>
    </header>
  )
}