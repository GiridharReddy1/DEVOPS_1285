import { createContext, useContext, useState } from 'react'

const AppointmentContext = createContext(null)

export function AppointmentProvider({ children }) {
  const [appointments, setAppointments] = useState([])

  const bookAppointment = (appointment) => {
    setAppointments((current) => [
      ...current,
      { ...appointment, id: `${Date.now()}-${Math.random()}` }
    ])
  }

  const cancelAppointment = (id) => {
    setAppointments((current) => current.filter((item) => item.id !== id))
  }

  return (
    <AppointmentContext.Provider value={{ appointments, bookAppointment, cancelAppointment }}>
      {children}
    </AppointmentContext.Provider>
  )
}

export function useAppointments() {
  return useContext(AppointmentContext)
}