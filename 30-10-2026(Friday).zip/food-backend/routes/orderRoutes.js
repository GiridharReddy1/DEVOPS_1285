const express = require("express");
const router = express.Router();

// In-memory order storage for this assignment demonstration.
const orders = [];
let nextOrderId = 1;

router.post("/", (req, res) => {
  const { customerName, items } = req.body;

  if (!customerName || typeof customerName !== "string" ||
      !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({
      message: "Provide customerName and a non-empty items array"
    });
  }

  const order = {
    id: nextOrderId++,
    customerName: customerName.trim(),
    items,
    status: "PLACED",
    createdAt: new Date().toISOString()
  };

  orders.push(order);
  res.status(201).json(order);
});

router.get("/", (req, res) => res.json(orders));

module.exports = router;
