# Food Delivery Backend (Assignment 11.2.3)

A Dockerized Node.js + Express backend for restaurant, food, and order APIs.

## Requirements
- Node.js 20+ and npm (for running locally)
- Docker Desktop (for container build/run)

## Run locally
```bash
npm install
npm start
```
The API runs at `http://localhost:5000`.

## API endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/health` | Health status |
| GET | `/api/restaurants` | List restaurants |
| GET | `/api/restaurants/:id` | Get one restaurant |
| GET | `/api/foods` | List food items |
| GET | `/api/foods/:id` | Get one food item |
| POST | `/api/orders` | Place an order |
| GET | `/api/orders` | List orders |

### Sample POST body
Send this JSON to `POST http://localhost:5000/api/orders`:
```json
{
  "customerName": "Asha",
  "items": [
    { "foodId": 101, "quantity": 2 }
  ]
}
```

## Build the Docker image
Run these commands from this `food-backend` directory:
```bash
docker build -t food-backend:v1 .
docker images
```

## Run the container
```bash
docker run -d --restart unless-stopped -p 5000:5000 --name food-api food-backend:v1
```

If a container named `food-api` already exists, remove it first:
```bash
docker rm -f food-api
```

## Test the container
```bash
docker ps
docker logs food-api
docker inspect food-api
```
Open `http://localhost:5000/health` and test the API endpoints using Postman.

## Stop and start
```bash
docker stop food-api
docker start food-api
```

## Docker network (bonus)
```bash
docker network create food-network
docker rm -f food-api
docker run -d --restart unless-stopped --network food-network -p 5000:5000 --name food-api food-backend:v1
```

## Notes
- `PORT` is configurable through an environment variable; default is `5000`.
- The image installs production dependencies only, uses a non-root `node` user, and includes a Docker health check.
- Orders are stored in memory to keep this assignment self-contained. They reset when the container restarts. The optional PostgreSQL/MongoDB extension is not included.
