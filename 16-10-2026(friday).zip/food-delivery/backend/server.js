const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

const restaurants = [
  { id: 1, name: "Spice Garden", cuisine: "Indian", rating: 4.7, time: "25-30 min" },
  { id: 2, name: "Pasta House", cuisine: "Italian", rating: 4.5, time: "20-25 min" },
  { id: 3, name: "Burger Barn", cuisine: "American", rating: 4.4, time: "15-20 min" }
];

const foods = [
  { id: 1, restaurantId: 1, name: "Paneer Biryani", description: "Aromatic rice with paneer", price: 220 },
  { id: 2, restaurantId: 1, name: "Masala Dosa", description: "Crispy dosa with potato masala", price: 120 },
  { id: 3, restaurantId: 2, name: "Creamy Alfredo Pasta", description: "Pasta in creamy white sauce", price: 260 },
  { id: 4, restaurantId: 3, name: "Classic Veg Burger", description: "Veg patty with house sauce", price: 150 }
];
const orders = [];
let nextOrderId = 1;

app.get("/", (req, res) => res.json({ message: "Welcome to Food Delivery API" }));
app.get("/api/restaurants", (req, res) => res.status(200).json(restaurants));
app.get("/api/foods", (req, res) => res.status(200).json(foods));
app.get("/api/orders", (req, res) => res.status(200).json(orders));

app.post("/api/orders", (req, res) => {
  const { customerName, address, phone, items } = req.body;
  const validItems = Array.isArray(items) && items.length > 0 &&
    items.every((item) => Number.isInteger(Number(item.id)) &&
      Number.isInteger(Number(item.quantity)) && Number(item.quantity) > 0 &&
      foods.some((food) => food.id === Number(item.id)));

  if (typeof customerName !== "string" || customerName.trim().length < 2 ||
      typeof address !== "string" || address.trim().length < 5 ||
      typeof phone !== "string" || !/^[0-9]{10}$/.test(phone) || !validItems) {
    return res.status(400).json({
      message: "Invalid order. Provide customerName, address, a 10-digit phone, and at least one valid food item."
    });
  }

  const orderItems = items.map((item) => {
    const food = foods.find((entry) => entry.id === Number(item.id));
    return { foodId: food.id, name: food.name, price: food.price, quantity: Number(item.quantity) };
  });
  const total = orderItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const order = {
    id: nextOrderId++, customerName: customerName.trim(),
    address: address.trim(), phone, items: orderItems, total, status: "Received"
  };
  orders.push(order);
  return res.status(201).json({ message: "Order placed successfully", order });
});

app.use((req, res) => res.status(404).json({ message: "Route not found" }));
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ message: "Internal server error" });
});

module.exports = app;

if (require.main === module) {
  const PORT = process.env.PORT || 5000;
  app.listen(PORT, () => console.log(`Food delivery API running at http://localhost:${PORT}`));
}
