const request = require("supertest");
const app = require("./server");

describe("Restaurant API", () => {
  test("GET /api/restaurants returns restaurant list", async () => {
    const response = await request(app).get("/api/restaurants");
    expect(response.statusCode).toBe(200);
    expect(response.body.length).toBeGreaterThan(0);
    expect(response.body[0]).toHaveProperty("name");
  });
});

describe("Food API", () => {
  test("GET /api/foods returns food menu", async () => {
    const response = await request(app).get("/api/foods");
    expect(response.statusCode).toBe(200);
    expect(response.body.some((food) => food.name === "Paneer Biryani")).toBe(true);
  });
});

describe("Order API", () => {
  test("GET /api/orders returns an array", async () => {
    const response = await request(app).get("/api/orders");
    expect(response.statusCode).toBe(200);
    expect(Array.isArray(response.body)).toBe(true);
  });

  test("POST /api/orders creates a valid order", async () => {
    const response = await request(app).post("/api/orders").send({
      customerName: "Asha Rao", address: "12 Lake Road", phone: "9876543210",
      items: [{ id: 1, quantity: 2 }]
    });
    expect(response.statusCode).toBe(201);
    expect(response.body.order.total).toBe(440);
    expect(response.body.order.status).toBe("Received");
  });
});

describe("Order validation", () => {
  test("rejects an order with missing customer details", async () => {
    const response = await request(app).post("/api/orders").send({
      customerName: "", address: "x", phone: "123", items: []
    });
    expect(response.statusCode).toBe(400);
    expect(response.body).toHaveProperty("message");
  });

  test("rejects unknown food IDs", async () => {
    const response = await request(app).post("/api/orders").send({
      customerName: "Asha Rao", address: "12 Lake Road", phone: "9876543210",
      items: [{ id: 999, quantity: 1 }]
    });
    expect(response.statusCode).toBe(400);
  });
});
