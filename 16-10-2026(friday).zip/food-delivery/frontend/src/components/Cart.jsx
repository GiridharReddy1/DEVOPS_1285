export function calculateCartTotal(items) {
  return items.reduce((total, item) => total + item.price * item.quantity, 0);
}

export default function Cart({ items, onChangeQuantity, onPlaceOrder, placing }) {
  const total = calculateCartTotal(items);
  return (
    <section className="panel cart-panel">
      <div className="panel-title"><h2>Your cart</h2><span>{items.reduce((n, item) => n + item.quantity, 0)} items</span></div>
      {items.length === 0 ? <p className="muted">Your cart is empty. Add something delicious!</p> : <>
        {items.map((item) => <div className="cart-row" key={item.id}>
          <div><strong>{item.name}</strong><small>₹{item.price} each</small></div>
          <div className="quantity"><button aria-label={`Remove one ${item.name}`} onClick={() => onChangeQuantity(item.id, -1)}>−</button><span>{item.quantity}</span><button aria-label={`Add one ${item.name}`} onClick={() => onChangeQuantity(item.id, 1)}>+</button></div>
        </div>)}
        <div className="total-row"><span>Total</span><strong>₹{total}</strong></div>
        <button className="checkout-button" onClick={onPlaceOrder} disabled={placing}>{placing ? "Placing order..." : "Place order"}</button>
      </>}
    </section>
  );
}
