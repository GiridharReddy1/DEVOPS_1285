import { useState } from "react";

export default function OrderForm({ onSubmit, onCancel }) {
  const [customerName, setCustomerName] = useState("");
  const [address, setAddress] = useState("");
  const [phone, setPhone] = useState("");

  const submit = (event) => {
    event.preventDefault();
    onSubmit({ customerName: customerName.trim(), address: address.trim(), phone: phone.trim() });
  };

  return (
    <div className="modal-backdrop">
      <form className="order-form" onSubmit={submit}>
        <h2>Delivery details</h2>
        <label>Your name<input required minLength="2" value={customerName} onChange={(e) => setCustomerName(e.target.value)} /></label>
        <label>Delivery address<textarea required minLength="5" value={address} onChange={(e) => setAddress(e.target.value)} /></label>
        <label>Phone number<input required pattern="[0-9]{10}" title="Enter a 10-digit phone number" value={phone} onChange={(e) => setPhone(e.target.value)} /></label>
        <div className="form-actions"><button className="checkout-button">Confirm order</button><button type="button" className="cancel-button" onClick={onCancel}>Cancel</button></div>
      </form>
    </div>
  );
}
