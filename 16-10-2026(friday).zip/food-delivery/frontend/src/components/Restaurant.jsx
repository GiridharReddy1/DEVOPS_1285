export default function Restaurant({ restaurant, selected, onSelect }) {
  return (
    <button className={`restaurant ${selected ? "selected" : ""}`} onClick={() => onSelect(restaurant.id)} aria-pressed={selected}>
      <span className="restaurant-emoji">{restaurant.emoji}</span>
      <span className="restaurant-copy"><strong>{restaurant.name}</strong><small>{restaurant.cuisine} · ⭐ {restaurant.rating} · {restaurant.time}</small></span>
    </button>
  );
}
