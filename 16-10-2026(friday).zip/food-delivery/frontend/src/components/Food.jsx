export default function Food({ food, onAdd }) {
  return (
    <article className="food-card">
      <div className="food-emoji">{food.emoji}</div>
      <div className="food-copy"><h3>{food.name}</h3><p>{food.description}</p><strong>₹{food.price}</strong></div>
      <button className="add-button" onClick={() => onAdd(food)}>Add +</button>
    </article>
  );
}
