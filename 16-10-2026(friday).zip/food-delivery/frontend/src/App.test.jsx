import { describe, it, expect, vi } from "vitest";
import { fireEvent, render, screen } from "@testing-library/react";
import App from "./App.jsx";
import Restaurant from "./components/Restaurant.jsx";
import Food from "./components/Food.jsx";
import Cart, { calculateCartTotal } from "./components/Cart.jsx";
import OrderForm from "./components/OrderForm.jsx";

describe("Restaurant component", () => {
  it("shows restaurant name and cuisine", () => {
    render(<Restaurant restaurant={{ id: 1, name: "Spice Garden", cuisine: "Indian", rating: 4.7, time: "25-30 min", emoji: "🍛" }} selected={false} onSelect={() => {}} />);
    expect(screen.getByText("Spice Garden")).toBeInTheDocument();
    expect(screen.getByText(/Indian/)).toBeInTheDocument();
  });
});

describe("Food component", () => {
  it("renders food details and invokes add callback", () => {
    const onAdd = vi.fn();
    const food = { id: 1, name: "Paneer Biryani", description: "Rice with paneer", price: 220, emoji: "🍚" };
    render(<Food food={food} onAdd={onAdd} />);
    expect(screen.getByText("Paneer Biryani")).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: /Add/ }));
    expect(onAdd).toHaveBeenCalledWith(food);
  });
});

describe("Cart calculation", () => {
  it("calculates total price using quantity", () => {
    expect(calculateCartTotal([{ price: 100, quantity: 2 }, { price: 50, quantity: 3 }])).toBe(350);
  });
});

describe("Order form", () => {
  it("submits customer delivery information", () => {
    const onSubmit = vi.fn();
    render(<OrderForm onSubmit={onSubmit} onCancel={() => {}} />);
    fireEvent.change(screen.getByLabelText("Your name"), { target: { value: "Asha Rao" } });
    fireEvent.change(screen.getByLabelText("Delivery address"), { target: { value: "12 Lake Road" } });
    fireEvent.change(screen.getByLabelText("Phone number"), { target: { value: "9876543210" } });
    fireEvent.click(screen.getByRole("button", { name: "Confirm order" }));
    expect(onSubmit).toHaveBeenCalledWith({ customerName: "Asha Rao", address: "12 Lake Road", phone: "9876543210" });
  });
});

describe("Food delivery app", () => {
  it("shows restaurants and the first restaurant menu", () => {
    render(<App />);
    expect(screen.getByText("Spice Garden")).toBeInTheDocument();
    expect(screen.getByText("Paneer Biryani")).toBeInTheDocument();
  });
});
