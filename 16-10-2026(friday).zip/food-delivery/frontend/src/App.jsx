import { useMemo, useState } from "react";
import { restaurants, foods } from "./data.js";
import Restaurant from "./components/Restaurant.jsx";
import Food from "./components/Food.jsx";
import Cart from "./components/Cart.jsx";
import OrderForm from "./components/OrderForm.jsx";

const API_URL = "http://localhost:5000/api";

export default function App() {
  const [restaurantId, setRestaurantId] = useState(1);
  const [cart, setCart] = useState([]);
  const [showOrderForm, setShowOrderForm] = useState(false);
  const [message, setMessage] = useState("");
  const [placing, setPlacing] = useState(false);

  const menu = useMemo(() => foods.filter((food) => food.restaurantId === restaurantId), [restaurantId]);

  const addToCart = (food) => {
    setCart((current) => {
      const existing = current.find((item) => item.id === food.id);
      return existing
        ? current.map((item) => item.id === food.id ? { ...item, quantity: item.quantity + 1 } : item)
        : [...current, { ...food, quantity: 1 }];
    });
    setMessage("");
  };

  const changeQuantity = (id, amount) => {
    setCart((current) => current
      .map((item) => item.id === id ? { ...item, quantity: item.quantity + amount } : item)
      .filter((item) => item.quantity > 0));
  };

  const placeOrder = async (customer) => {
    try {
      setPlacing(true);
      const response = await fetch(`${API_URL}/orders`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...customer, items: cart, total: cart.reduce((sum, item) => sum + item.price * item.quantity, 0) })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.message || "Unable to place order");
      setCart([]);
      setShowOrderForm(false);
      setMessage(`Order #${data.order.id} placed successfully!`);
    } catch (error) {
      setMessage(error.message || "Could not connect to the order API. Start the backend and try again.");
    } finally {
      setPlacing(false);
    }
  };

  return (
    <div className="app-shell">
      <header className="topbar"><a className="logo" href="/">quick<span>bite</span>.</a><span className="delivery-label">DELIVERING HAPPINESS <b>⌄</b></span></header>
      <main className="page">
        <section className="welcome"><div><p className="eyebrow">GOOD FOOD, GOOD MOOD</p><h1>What are you<br /><em>craving today?</em></h1><p>Discover local favorites and get them delivered fresh.</p></div><div className="welcome-art">🥡</div></section>
        {message && <div className="notice" role="status">{message}</div>}
        <div className="section-heading"><div><p className="eyebrow">PICK YOUR FAVORITE</p><h2>Restaurants near you</h2></div></div>
        <section className="restaurant-list" aria-label="Restaurants">
          {restaurants.map((restaurant) => <Restaurant key={restaurant.id} restaurant={restaurant} selected={restaurant.id === restaurantId} onSelect={setRestaurantId} />)}
        </section>
        <div className="main-grid">
          <section><div className="section-heading menu-heading"><div><p className="eyebrow">FRESHLY PREPARED</p><h2>Popular from {restaurants.find((r) => r.id === restaurantId)?.name}</h2></div></div>
            <div className="food-list">{menu.map((food) => <Food key={food.id} food={food} onAdd={addToCart} />)}</div>
          </section>
          <Cart items={cart} onChangeQuantity={changeQuantity} onPlaceOrder={() => setShowOrderForm(true)} placing={placing} />
        </div>
        <footer>quickbite. · Made for food lovers</footer>
      </main>
      {showOrderForm && <OrderForm onSubmit={placeOrder} onCancel={() => setShowOrderForm(false)} />}
    </div>
  );
}
