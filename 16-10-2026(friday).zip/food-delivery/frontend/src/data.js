export const restaurants = [
  { id: 1, name: "Spice Garden", cuisine: "Indian", rating: 4.7, time: "25-30 min", emoji: "🍛" },
  { id: 2, name: "Pasta House", cuisine: "Italian", rating: 4.5, time: "20-25 min", emoji: "🍝" },
  { id: 3, name: "Burger Barn", cuisine: "American", rating: 4.4, time: "15-20 min", emoji: "🍔" }
];

export const foods = [
  { id: 1, restaurantId: 1, name: "Paneer Biryani", description: "Aromatic basmati rice with paneer and spices.", price: 220, emoji: "🍚" },
  { id: 2, restaurantId: 1, name: "Masala Dosa", description: "Crispy dosa with potato masala.", price: 120, emoji: "🥞" },
  { id: 3, restaurantId: 2, name: "Creamy Alfredo Pasta", description: "Pasta tossed in a creamy white sauce.", price: 260, emoji: "🍝" },
  { id: 4, restaurantId: 3, name: "Classic Veg Burger", description: "A fresh veggie patty with house sauce.", price: 150, emoji: "🍔" }
];
