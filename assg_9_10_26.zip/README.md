# Online Book Store

A React single-page application for the DEVOPS AND FULLSTACK Assignment 9.2.3.

## Features
- React Router routes: Home, Books, Book Details, Categories, Cart, Profile, and 404.
- Dynamic `/books/:bookId` routes using `useParams()`.
- `useEffect()` loading state, bookId change detection, and cleanup logging.
- Search and category filtering.
- Add/remove cart items and cart quantity.
- Previous/Next book navigation.
- Recently viewed books.
- `useNavigate()` navigation.

## Requirements
- Node.js (LTS recommended)
- VS Code

## Run locally
Open this folder in VS Code terminal and run:

```bash
npm install
npm run dev
```

Open the local URL shown by Vite, usually `http://localhost:5173`.

## Production build
```bash
npm run build
npm run preview
```

Book data is stored locally in `src/data/books.js`; cart and recently viewed items are held in React state and reset when the page is refreshed.
