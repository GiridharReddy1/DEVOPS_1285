export const books = [
  {
    id: "B101",
    title: "Python Programming",
    author: "Mark Lutz",
    category: "Programming",
    price: 499,
    rating: 4.8,
    description:
      "A practical introduction to Python syntax, programming fundamentals, and building useful applications.",
    cover: "https://images.unsplash.com/photo-1515879218367-8466d910aaa4?auto=format&fit=crop&w=700&q=80"
  },
  {
    id: "B102",
    title: "Web Development",
    author: "Jon Duckett",
    category: "Web Development",
    price: 599,
    rating: 4.7,
    description:
      "Learn the core ideas behind building websites with HTML, CSS, JavaScript, and modern web practices.",
    cover: "https://images.unsplash.com/photo-1547658719-da2b51169166?auto=format&fit=crop&w=700&q=80"
  },
  {
    id: "B103",
    title: "Machine Learning",
    author: "Aurélien Géron",
    category: "Artificial Intelligence",
    price: 749,
    rating: 4.9,
    description:
      "Explore machine-learning concepts, model training, evaluation, and practical intelligent systems.",
    cover: "https://images.unsplash.com/photo-1555949957-3d1f3f3f3e4a?auto=format&fit=crop&w=700&q=80"
  },
  {
    id: "B104",
    title: "Clean Code",
    author: "Robert C. Martin",
    category: "Programming",
    price: 650,
    rating: 4.8,
    description:
      "Improve code readability, maintainability, naming, functions, and software craftsmanship.",
    cover: "https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=700&q=80"
  },
  {
    id: "B105",
    title: "Database Systems",
    author: "Thomas Connolly",
    category: "Database",
    price: 699,
    rating: 4.6,
    description:
      "Understand relational databases, data modelling, SQL, transactions, and database design.",
    cover: "https://images.unsplash.com/photo-1532012197267-da84d127e765?auto=format&fit=crop&w=700&q=80"
  },
  {
    id: "B106",
    title: "Data Structures & Algorithms",
    author: "Narasimha Karumanchi",
    category: "Computer Science",
    price: 549,
    rating: 4.7,
    description:
      "Practice fundamental data structures, algorithmic techniques, and problem-solving patterns.",
    cover: "https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&w=700&q=80"
  }
];

export const categories = [...new Set(books.map((book) => book.category))];