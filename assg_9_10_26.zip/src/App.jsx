import { useEffect, useMemo, useState } from "react";
import {
  Link,
  NavLink,
  Route,
  Routes,
  useNavigate,
  useParams
} from "react-router-dom";
import { books, categories } from "./data/books.js";

function Header({ cartCount }) {
  const navClass = ({ isActive }) => `nav-link${isActive ? " active" : ""}`;

  return (
    <header className="site-header">
      <div className="header-inner">
        <Link className="brand" to="/" aria-label="Online Book Store home">
          <span className="brand-mark">B</span>
          <span>Book<span className="brand-accent">Nest</span></span>
        </Link>
        <nav className="navigation" aria-label="Main navigation">
          <NavLink end to="/" className={navClass}>Home</NavLink>
          <NavLink to="/books" className={navClass}>Books</NavLink>
          <NavLink to="/categories" className={navClass}>Categories</NavLink>
          <NavLink to="/profile" className={navClass}>Profile</NavLink>
          <NavLink to="/cart" className={navClass}>
            Cart <span className="cart-count">{cartCount}</span>
          </NavLink>
        </nav>
      </div>
    </header>
  );
}

function BookCard({ book, onAddToCart }) {
  return (
    <article className="book-card">
      <Link className="cover-wrap" to={`/books/${book.id}`} aria-label={`View ${book.title}`}>
        <img src={book.cover} alt={`Cover illustration for ${book.title}`} loading="lazy" />
        <span className="book-id">{book.id}</span>
      </Link>
      <div className="book-card-body">
        <span className="eyebrow">{book.category}</span>
        <h3><Link to={`/books/${book.id}`}>{book.title}</Link></h3>
        <p className="muted">by {book.author}</p>
        <div className="book-card-footer">
          <span className="price">₹{book.price}</span>
          <span className="rating">★ {book.rating}</span>
        </div>
        <button className="button button-small" onClick={() => onAddToCart(book)}>
          Add to cart
        </button>
      </div>
    </article>
  );
}

function BookGrid({ items, onAddToCart }) {
  if (!items.length) {
    return <div className="empty-state"><h3>No books found</h3><p>Try another search or category.</p></div>;
  }
  return <div className="book-grid">{items.map((book) =>
    <BookCard key={book.id} book={book} onAddToCart={onAddToCart} />
  )}</div>;
}

function Home({ onAddToCart }) {
  const featured = books.slice(0, 3);
  return (
    <>
      <section className="hero">
        <div className="hero-copy">
          <span className="pill">YOUR NEXT CHAPTER STARTS HERE</span>
          <h1>Stories and skills<br /><span>for every curious mind.</span></h1>
          <p>Discover your next favourite read, from programming essentials to ideas that shape tomorrow.</p>
          <div className="hero-actions">
            <Link className="button" to="/books">Explore books <span aria-hidden="true">→</span></Link>
            <Link className="text-link" to="/categories">Browse categories</Link>
          </div>
          <div className="hero-stats">
            <div><strong>1,200+</strong><span>Books to discover</span></div>
            <div><strong>4.8/5</strong><span>Reader rating</span></div>
            <div><strong>Easy</strong><span>One-page browsing</span></div>
          </div>
        </div>
        <div className="hero-art">
          <div className="art-orbit orbit-one"></div>
          <div className="art-orbit orbit-two"></div>
          <div className="floating-book book-back"><span>LEARN</span></div>
          <div className="floating-book book-front"><span>IDEAS<br />INTO<br />ACTION</span><small>BOOKNEST EDITION</small></div>
          <div className="art-note">A little reading<br />goes a long way ✦</div>
        </div>
      </section>
      <section className="section">
        <div className="section-heading">
          <div><span className="eyebrow">HANDPICKED FOR YOU</span><h2>Featured books</h2></div>
          <Link className="text-link" to="/books">View all books →</Link>
        </div>
        <BookGrid items={featured} onAddToCart={onAddToCart} />
      </section>
      <section className="category-strip">
        <div><span className="eyebrow">FIND YOUR INTEREST</span><h2>Explore by category</h2></div>
        <div className="category-chips">{categories.slice(0, 4).map((category) =>
          <Link key={category} to={`/categories?category=${encodeURIComponent(category)}`}>{category} <span>↗</span></Link>
        )}</div>
      </section>
    </>
  );
}

function BookList({ onAddToCart }) {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");
  const filteredBooks = useMemo(() => books.filter((book) => {
    const query = search.trim().toLowerCase();
    const matchesSearch = !query || [book.title, book.author, book.id, book.category]
      .some((value) => value.toLowerCase().includes(query));
    return matchesSearch && (category === "All" || book.category === category);
  }), [search, category]);

  return (
    <main className="page section">
      <div className="page-heading"><span className="eyebrow">THE BOOKSHELF</span><h1>All books</h1>
        <p>Find practical guides and new ideas for your next learning goal.</p></div>
      <div className="filters">
        <label className="search-box"><span>⌕</span><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search title, author, ID..." /></label>
        <select aria-label="Filter by category" value={category} onChange={(e) => setCategory(e.target.value)}>
          <option value="All">All categories</option>
          {categories.map((item) => <option key={item}>{item}</option>)}
        </select>
        <span className="results-count">{filteredBooks.length} books</span>
      </div>
      <BookGrid items={filteredBooks} onAddToCart={onAddToCart} />
    </main>
  );
}

function BookDetails({ onAddToCart, onViewed }) {
  const { bookId } = useParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [book, setBook] = useState(null);

  useEffect(() => {
    let isActive = true;
    setLoading(true);
    setError("");
    console.log("Loading book details:", bookId);

    const timer = setTimeout(() => {
      const found = books.find((item) => item.id.toLowerCase() === bookId?.toLowerCase());
      if (!isActive) return;
      if (found) {
        setBook(found);
        onViewed(found);
      } else {
        setBook(null);
        setError(`We couldn't find a book with ID "${bookId}".`);
      }
      setLoading(false);
    }, 350);

    return () => {
      isActive = false;
      clearTimeout(timer);
      console.log("Leaving book details:", bookId);
    };
  }, [bookId, onViewed]);

  if (loading) return <main className="page section"><div className="loading-state"><span className="spinner"></span><h2>Loading book details...</h2><p>Please wait a moment.</p></div></main>;
  if (error) return <main className="page section"><div className="empty-state"><span className="error-mark">!</span><h2>Book not found</h2><p>{error}</p><button className="button" onClick={() => navigate("/books")}>Back to books</button></div></main>;
  if (!book) return null;

  const index = books.findIndex((item) => item.id === book.id);
  const previous = books[(index - 1 + books.length) % books.length];
  const next = books[(index + 1) % books.length];

  return (
    <main className="page section">
      <div className="breadcrumbs"><Link to="/">Home</Link><span>/</span><Link to="/books">Books</Link><span>/</span><span>{book.id}</span></div>
      <div className="detail-layout">
        <div className="detail-cover"><img src={book.cover} alt={`Cover illustration for ${book.title}`} /></div>
        <div className="detail-copy">
          <span className="eyebrow">{book.category} · {book.id}</span>
          <h1>{book.title}</h1><p className="muted">Written by {book.author}</p>
          <div className="detail-rating"><span>★ {book.rating}</span><span>Reader favourite</span></div>
          <p className="detail-description">{book.description}</p>
          <div className="detail-price">₹{book.price}</div>
          <div className="detail-actions"><button className="button" onClick={() => onAddToCart(book)}>Add to cart</button><button className="button button-outline" onClick={() => navigate("/cart")}>Go to cart</button></div>
          <div className="detail-meta"><div><span>Format</span><strong>Paperback</strong></div><div><span>Availability</span><strong className="available">In stock</strong></div><div><span>Delivery</span><strong>3–5 working days</strong></div></div>
          <div className="previous-next"><button onClick={() => navigate(`/books/${previous.id}`)}>← {previous.title}</button><button onClick={() => navigate(`/books/${next.id}`)}>{next.title} →</button></div>
        </div>
      </div>
    </main>
  );
}

function Categories() {
  const navigate = useNavigate();
  return (
    <main className="page section">
      <div className="page-heading"><span className="eyebrow">EXPLORE YOUR INTERESTS</span><h1>Categories</h1><p>Choose a subject to find your next read.</p></div>
      <div className="category-grid">{categories.map((category, index) => {
        const count = books.filter((book) => book.category === category).length;
        return <button className="category-card" key={category} onClick={() => navigate(`/books?category=${encodeURIComponent(category)}`)}>
          <span className="category-number">0{index + 1}</span><span className="category-icon">{["⌘", "✳", "◈", "▤", "⌁"][index % 5]}</span>
          <h2>{category}</h2><p>{count} {count === 1 ? "book" : "books"}</p><span className="category-arrow">↗</span>
        </button>;
      })}</div>
    </main>
  );
}

function Cart({ cart, onRemove, onChangeQuantity, onContinueShopping }) {
  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  return (
    <main className="page section">
      <div className="page-heading"><span className="eyebrow">YOUR SELECTION</span><h1>Shopping cart</h1><p>Review the books you want to take home.</p></div>
      {!cart.length ? <div className="empty-state"><span className="empty-cart">♡</span><h2>Your cart is waiting for a good book</h2><p>Explore the bookshelf and add something you love.</p><button className="button" onClick={onContinueShopping}>Explore books</button></div> :
        <div className="cart-layout"><div className="cart-items">{cart.map((item) => <article className="cart-item" key={item.id}>
          <img src={item.cover} alt="" /><div className="cart-item-info"><span className="eyebrow">{item.id}</span><h3><Link to={`/books/${item.id}`}>{item.title}</Link></h3><p className="muted">{item.author}</p><button className="remove-link" onClick={() => onRemove(item.id)}>Remove</button></div>
          <div className="quantity-control"><button aria-label={`Decrease ${item.title} quantity`} onClick={() => onChangeQuantity(item.id, item.quantity - 1)}>−</button><span>{item.quantity}</span><button aria-label={`Increase ${item.title} quantity`} onClick={() => onChangeQuantity(item.id, item.quantity + 1)}>+</button></div><strong>₹{item.price * item.quantity}</strong>
        </article>)}</div>
        <aside className="order-summary"><h2>Order summary</h2><div><span>Subtotal</span><strong>₹{total}</strong></div><div><span>Delivery</span><strong className="available">Free</strong></div><div className="summary-total"><span>Total</span><strong>₹{total}</strong></div><button className="button button-full" onClick={() => window.alert("Demo checkout: your order has not been placed.")}>Proceed to checkout</button><p className="fine-print">Demo checkout only. No payment is processed.</p></aside></div>}
    </main>
  );
}

function Profile({ recentlyViewed }) {
  return (
    <main className="page section">
      <div className="page-heading"><span className="eyebrow">YOUR READING SPACE</span><h1>Profile</h1><p>A little corner for your reading journey.</p></div>
      <div className="profile-panel"><div className="avatar">R</div><div><span className="eyebrow">READER ACCOUNT</span><h2>Welcome, Reader!</h2><p className="muted">Guest profile · Online Book Store</p></div><span className="profile-badge">Guest</span></div>
      <section className="section compact-section"><div className="section-heading"><div><span className="eyebrow">PICK UP WHERE YOU LEFT OFF</span><h2>Recently viewed</h2></div></div>
        {recentlyViewed.length ? <div className="recent-list">{recentlyViewed.map((book) => <Link className="recent-item" key={book.id} to={`/books/${book.id}`}><img src={book.cover} alt="" /><span><strong>{book.title}</strong><small>{book.category}</small></span><span>↗</span></Link>)}</div> : <div className="empty-state compact-empty"><p>You haven't viewed any books yet.</p><Link className="text-link" to="/books">Browse books →</Link></div>}
      </section>
    </main>
  );
}

function NotFound() {
  return <main className="page section"><div className="not-found"><span>404</span><h1>This page wandered off.</h1><p>The page you’re looking for doesn’t exist or may have moved.</p><Link className="button" to="/">Return home</Link></div></main>;
}

function Footer() {
  return <footer className="site-footer"><div className="footer-inner"><Link className="brand footer-brand" to="/"><span className="brand-mark">B</span><span>Book<span className="brand-accent">Nest</span></span></Link><p>Good books. Curious minds. Better tomorrows.</p><span>© {new Date().getFullYear()} Online Book Store · React Router assignment</span></div></footer>;
}

export default function App() {
  const [cart, setCart] = useState([]);
  const [recentlyViewed, setRecentlyViewed] = useState([]);
  const addToCart = (book) => setCart((current) => {
    const existing = current.find((item) => item.id === book.id);
    if (existing) return current.map((item) => item.id === book.id ? { ...item, quantity: item.quantity + 1 } : item);
    return [...current, { ...book, quantity: 1 }];
  });
  const removeFromCart = (id) => setCart((current) => current.filter((item) => item.id !== id));
  const changeQuantity = (id, quantity) => {
    if (quantity < 1) return removeFromCart(id);
    setCart((current) => current.map((item) => item.id === id ? { ...item, quantity } : item));
  };
  const rememberViewed = (book) => setRecentlyViewed((current) => [book, ...current.filter((item) => item.id !== book.id)].slice(0, 4));

  return (
    <div className="app-shell">
      <Header cartCount={cart.reduce((sum, item) => sum + item.quantity, 0)} />
      <Routes>
        <Route path="/" element={<Home onAddToCart={addToCart} />} />
        <Route path="/books" element={<BookList onAddToCart={addToCart} />} />
        <Route path="/books/:bookId" element={<BookDetails onAddToCart={addToCart} onViewed={rememberViewed} />} />
        <Route path="/categories" element={<Categories />} />
        <Route path="/cart" element={<Cart cart={cart} onRemove={removeFromCart} onChangeQuantity={changeQuantity} onContinueShopping={() => window.location.assign("/books")} />} />
        <Route path="/profile" element={<Profile recentlyViewed={recentlyViewed} />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
      <Footer />
    </div>
  );
}