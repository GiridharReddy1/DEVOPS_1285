const mongoose = require("mongoose");

const studentSchema = new mongoose.Schema(
  {
    studentId: {
      type: String,
      required: [true, "Student ID is required"],
      unique: true,
      trim: true
    },
    studentName: {
      type: String,
      required: [true, "Student Name is required"],
      trim: true,
      minlength: [2, "Student Name must contain at least 2 characters"]
    },
    department: {
      type: String,
      required: [true, "Department is required"],
      trim: true
    },
    email: {
      type: String,
      required: [true, "Email is required"],
      unique: true,
      trim: true,
      lowercase: true,
      match: [/^[^\s@]+@[^\s@]+\.[^\s@]+$/, "Please enter a valid email address"]
    },
    cgpa: {
      type: Number,
      required: [true, "CGPA is required"],
      min: [0, "CGPA cannot be less than 0"],
      max: [10, "CGPA cannot be greater than 10"]
    }
  },
  { timestamps: true }
);

module.exports = mongoose.model("Student", studentSchema);
