const Student = require("../models/Student");

function handleError(res, error) {
  if (error.code === 11000) {
    const field = Object.keys(error.keyPattern || {})[0] || "field";
    return res.status(409).json({ message: `${field} already exists` });
  }
  if (error.name === "ValidationError" || error.name === "CastError") {
    return res.status(400).json({ message: error.message });
  }
  console.error(error);
  return res.status(500).json({ message: "Internal server error" });
}

// POST /api/students - Add a student
exports.createStudent = async (req, res) => {
  try {
    const student = await Student.create(req.body);
    return res.status(201).json({
      message: "Student added successfully",
      student
    });
  } catch (error) {
    return handleError(res, error);
  }
};

// GET /api/students - Retrieve all students
// Optional query: ?department=CSE and ?sortByCgpa=asc|desc
exports.getStudents = async (req, res) => {
  try {
    const filter = {};
    if (req.query.department) {
      filter.department = new RegExp(`^${req.query.department.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}$`, "i");
    }

    let query = Student.find(filter);
    if (req.query.sortByCgpa === "asc") query = query.sort({ cgpa: 1 });
    if (req.query.sortByCgpa === "desc") query = query.sort({ cgpa: -1 });

    const students = await query;
    return res.status(200).json(students);
  } catch (error) {
    return handleError(res, error);
  }
};

// GET /api/students/:id - Retrieve one student by MongoDB document ID
exports.getStudentById = async (req, res) => {
  try {
    const student = await Student.findById(req.params.id);
    if (!student) return res.status(404).json({ message: "Student not found" });
    return res.status(200).json(student);
  } catch (error) {
    return handleError(res, error);
  }
};

// PUT /api/students/:id - Update student information
exports.updateStudent = async (req, res) => {
  try {
    const student = await Student.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );
    if (!student) return res.status(404).json({ message: "Student not found" });
    return res.status(200).json({ message: "Student updated successfully", student });
  } catch (error) {
    return handleError(res, error);
  }
};

// DELETE /api/students/:id - Delete a student
exports.deleteStudent = async (req, res) => {
  try {
    const student = await Student.findByIdAndDelete(req.params.id);
    if (!student) return res.status(404).json({ message: "Student not found" });
    return res.status(200).json({ message: "Student deleted successfully", student });
  } catch (error) {
    return handleError(res, error);
  }
};

// GET /api/students/count - Count all students
exports.countStudents = async (req, res) => {
  try {
    const count = await Student.countDocuments();
    return res.status(200).json({ totalStudents: count });
  } catch (error) {
    return handleError(res, error);
  }
};
