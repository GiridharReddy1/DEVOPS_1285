# Student Information Management API

This project implements the Week 5.1 lab scenario: Student Information Management System using MongoDB and Mongoose ODM.

## Requirements

- Node.js and npm
- MongoDB Community Server running locally, or a MongoDB Atlas connection string
- MongoDB Compass (optional GUI for viewing the database)
- Postman (for API testing)

## 1. Install and configure

Open a terminal in this project folder:

```bash
npm install
```

Copy `.env.example` to `.env` and keep the local MongoDB connection string:

```env
PORT=3000
MONGO_URI=mongodb://127.0.0.1:27017/student_db
```

If using Windows PowerShell, copy the environment file with:

```powershell
Copy-Item .env.example .env
```

Make sure MongoDB is running before starting the server. The database `student_db` and the `students` collection are created by MongoDB when the first student document is inserted.

## 2. Start the server

```bash
npm run dev
```

Expected terminal message:

```text
MongoDB connected successfully
Server running at http://localhost:3000
```

Open `http://localhost:3000/` in a browser to check the welcome endpoint.

## 3. API endpoints

| Method | Endpoint | Description |
|---|---|---|
| GET | `/` | Welcome message |
| POST | `/api/students` | Add a student |
| GET | `/api/students` | Retrieve all students |
| GET | `/api/students/:id` | Retrieve one student by MongoDB document ID |
| PUT | `/api/students/:id` | Update a student |
| DELETE | `/api/students/:id` | Delete a student |
| GET | `/api/students?department=CSE` | Search by department |
| GET | `/api/students?sortByCgpa=asc` | Sort by CGPA ascending |
| GET | `/api/students?sortByCgpa=desc` | Sort by CGPA descending |
| GET | `/api/students/count` | Count all students |

### Example POST body

Choose **POST**, set URL to `http://localhost:3000/api/students`, select **Body → raw → JSON**, and send:

```json
{
  "studentId": "SRU2026001",
  "studentName": "Asha Rao",
  "department": "CSE",
  "email": "asha@example.com",
  "cgpa": 8.7
}
```

A successful insert returns HTTP `201 Created`. Copy the returned MongoDB `_id` for GET, PUT and DELETE requests. The `studentId` is the university's unique student number; the `:id` URL parameter is MongoDB's document `_id`.

### Example update body

```json
{
  "department": "AIML",
  "cgpa": 9.1
}
```

## 4. Validation and error handling

- Student ID is required and unique.
- Student name and department are required.
- Email is required, converted to lowercase, and checked against an email format pattern.
- CGPA must be a number between 0 and 10.
- Duplicate student IDs or emails return HTTP `409 Conflict`.
- Invalid fields or malformed IDs return HTTP `400 Bad Request`.
- A student that does not exist returns HTTP `404 Not Found`.
- Successful creation returns `201`; successful reads, updates and deletes return `200`.

## 5. MongoDB Compass

1. Open MongoDB Compass.
2. Connect using `mongodb://127.0.0.1:27017`.
3. Find the `student_db` database.
4. Open the `students` collection after the first student has been inserted.
5. View the saved student documents.

## 6. Postman collection

Import `postman/Student-Management-API.postman_collection.json` into Postman. The collection includes requests for create, read, update, delete, department search, CGPA sorting and count.

## Project structure

```text
student-information-management/
├── config/
│   └── db.js
├── controllers/
│   └── studentController.js
├── middleware/
│   └── notFound.js
├── models/
│   └── Student.js
├── routes/
│   └── studentRoutes.js
├── postman/
│   └── Student-Management-API.postman_collection.json
├── .env.example
├── .gitignore
├── package.json
├── README.md
└── server.js
```

## Note

This is a backend API for the lab scenario; a React frontend and authentication were not requested in the provided task sheet.
