const express = require("express");
const router = express.Router();
const {
  createStudent,
  getStudents,
  getStudentById,
  updateStudent,
  deleteStudent,
  countStudents
} = require("../controllers/studentController");

// Put /count before /:id so it is not treated as a student ID.
router.get("/count", countStudents);
router.route("/")
  .post(createStudent)
  .get(getStudents);

router.route("/:id")
  .get(getStudentById)
  .put(updateStudent)
  .delete(deleteStudent);

module.exports = router;
