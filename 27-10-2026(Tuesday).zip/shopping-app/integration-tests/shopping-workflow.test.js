const axios = require("axios");

const api = axios.create({ baseURL: process.env.API_URL || "http://localhost:5000/api" });

describe("Complete shopping integration workflow", () => {
  let selectedProduct;

  test("1. Retrieve products", async () => {
    const response = await api.get("/products");
    expect(response.status).toBe(200);
    expect(response.data.length).toBeGreaterThan(0);
    selectedProduct = response.data.find((product) => product.id === 101);
    expect(selectedProduct.name).toBe("Laptop");
  });

  test("2. Add selected product to cart", async () => {
    const response = await api.post("/cart", { productId: selectedProduct.id, quantity: 1 });
    expect([200, 201]).toContain(response.status);
    expect(response.data.item.id).toBe(101);
  });

  test("3. Update cart quantity", async () => {
    const response = await api.put("/cart/101", { quantity: 2 });
    expect(response.status).toBe(200);
    expect(response.data.item.quantity).toBe(2);
  });

  test("4. Verify cart total calculation", async () => {
    const response = await api.get("/cart");
    expect(response.status).toBe(200);
    expect(response.data.total).toBe(120000);
  });

  test("5. Place order", async () => {
    const response = await api.post("/orders");
    expect(response.status).toBe(201);
    expect(response.data.order.total).toBe(120000);
    expect(response.data.order.items[0].quantity).toBe(2);
  });

  test("6. Verify order appears in order history", async () => {
    const response = await api.get("/orders");
    expect(response.status).toBe(200);
    expect(response.data.length).toBeGreaterThan(0);
    expect(response.data[response.data.length - 1].total).toBe(120000);
  });
});
