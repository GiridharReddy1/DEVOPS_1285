const request = require("supertest");
const app = require("./server");

describe("Shopping API", () => {
  test("GET /api/products returns product list", async () => {
    const response = await request(app).get("/api/products");
    expect(response.status).toBe(200);
    expect(response.body).toEqual(expect.arrayContaining([
      expect.objectContaining({ id: 101, name: "Laptop", price: 60000 })
    ]));
  });

  test("GET /api/products/:id returns a product", async () => {
    const response = await request(app).get("/api/products/101");
    expect(response.status).toBe(200);
    expect(response.body.name).toBe("Laptop");
  });

  test("GET unknown product returns 404", async () => {
    const response = await request(app).get("/api/products/9999");
    expect(response.status).toBe(404);
  });

  test("POST /api/cart validates quantity", async () => {
    const response = await request(app).post("/api/cart").send({ productId: 101, quantity: 0 });
    expect(response.status).toBe(400);
  });
});
