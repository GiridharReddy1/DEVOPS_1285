const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

// Sample in-memory data for this assignment.
const products = [
  { id: 101, name: "Laptop", price: 60000, category: "Electronics" },
  { id: 102, name: "Headphones", price: 2000, category: "Electronics" },
  { id: 103, name: "Backpack", price: 1500, category: "Accessories" }
];

let cart = [];
let orders = [];
let nextOrderId = 1;

app.get("/", (req, res) => {
  res.json({ message: "Welcome to Shopping App API" });
});

// Product APIs
app.get("/api/products", (req, res) => res.status(200).json(products));

app.get("/api/products/:id", (req, res) => {
  const product = products.find((item) => item.id === Number(req.params.id));
  if (!product) return res.status(404).json({ message: "Product not found" });
  return res.status(200).json(product);
});

// Add product to cart. One cart row per product ID.
app.post("/api/cart", (req, res) => {
  const { productId, quantity = 1 } = req.body;
  const product = products.find((item) => item.id === Number(productId));
  const qty = Number(quantity);

  if (!product) return res.status(404).json({ message: "Product not found" });
  if (!Number.isInteger(qty) || qty <= 0) {
    return res.status(400).json({ message: "Quantity must be a positive integer" });
  }

  const existing = cart.find((item) => item.id === product.id);
  if (existing) {
    existing.quantity += qty;
    return res.status(200).json({ message: "Cart quantity increased", item: existing });
  }

  const item = { ...product, quantity: qty };
  cart.push(item);
  return res.status(201).json({ message: "Product added to cart", item });
});

// Update quantity using the product ID, as specified in the assignment.
app.put("/api/cart/:id", (req, res) => {
  const item = cart.find((entry) => entry.id === Number(req.params.id));
  if (!item) return res.status(404).json({ message: "Cart item not found" });

  const quantity = Number(req.body.quantity);
  if (!Number.isInteger(quantity) || quantity <= 0) {
    return res.status(400).json({ message: "Quantity must be a positive integer" });
  }

  item.quantity = quantity;
  return res.status(200).json({ message: "Cart quantity updated", item });
});

app.delete("/api/cart/:id", (req, res) => {
  const index = cart.findIndex((item) => item.id === Number(req.params.id));
  if (index === -1) return res.status(404).json({ message: "Cart item not found" });
  const [removed] = cart.splice(index, 1);
  return res.status(200).json({ message: "Product removed from cart", item: removed });
});

app.get("/api/cart", (req, res) => res.status(200).json({
  items: cart,
  total: cart.reduce((sum, item) => sum + item.price * item.quantity, 0)
}));

// Place an order using all current cart items.
app.post("/api/orders", (req, res) => {
  if (cart.length === 0) {
    return res.status(400).json({ message: "Cart is empty" });
  }

  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const order = {
    id: nextOrderId++,
    items: cart.map((item) => ({ ...item })),
    total,
    status: "Placed",
    createdAt: new Date().toISOString()
  };

  orders.push(order);
  cart = [];
  return res.status(201).json({ message: "Order created successfully", order });
});

app.get("/api/orders", (req, res) => res.status(200).json(orders));

app.use((req, res) => res.status(404).json({ message: "Route not found" }));
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ message: "Internal server error" });
});

module.exports = app;

if (require.main === module) {
  const PORT = process.env.PORT || 5000;
  app.listen(PORT, () => console.log(`Shopping API running at http://localhost:${PORT}`));
}
