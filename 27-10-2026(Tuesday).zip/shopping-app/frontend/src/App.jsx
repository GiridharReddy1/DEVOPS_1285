import { useEffect, useMemo, useState } from "react";
import axios from "axios";

const api = axios.create({ baseURL: "http://localhost:5000/api" });

export default function App() {
  const [products, setProducts] = useState([]);
  const [cart, setCart] = useState({ items: [], total: 0 });
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  const load = async () => {
    try {
      setLoading(true);
      const [productResponse, cartResponse] = await Promise.all([
        api.get("/products"), api.get("/cart")
      ]);
      setProducts(productResponse.data);
      setCart(cartResponse.data);
      setError("");
    } catch {
      setError("Unable to connect to the API. Please start the backend on port 5000.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const filtered = useMemo(() => products.filter((p) =>
    `${p.name} ${p.category}`.toLowerCase().includes(search.toLowerCase())
  ), [products, search]);

  const addToCart = async (productId) => {
    try {
      await api.post("/cart", { productId, quantity: 1 });
      await refreshCart();
      setMessage("Product added to cart.");
    } catch (err) { setMessage(err.response?.data?.message || "Could not add product."); }
  };

  const refreshCart = async () => {
    const response = await api.get("/cart");
    setCart(response.data);
  };

  const updateQuantity = async (id, quantity) => {
    try {
      if (quantity <= 0) await api.delete(`/cart/${id}`);
      else await api.put(`/cart/${id}`, { quantity });
      await refreshCart();
    } catch (err) { setMessage(err.response?.data?.message || "Could not update cart."); }
  };

  const placeOrder = async () => {
    try {
      const response = await api.post("/orders");
      setMessage(`Order #${response.data.order.id} placed successfully!`);
      await refreshCart();
    } catch (err) { setMessage(err.response?.data?.message || "Could not place order."); }
  };

  return (
    <div className="app">
      <header><a className="logo" href="/">shop<span>smart</span>.</a><span className="cart-count">🛒 {cart.items.length} product(s)</span></header>
      <main>
        <section className="hero"><div><p className="eyebrow">SMART PICKS, SIMPLE SHOPPING</p><h1>Find what you<br/><em>love to own.</em></h1><p>Explore our collection and add your favorites to the cart.</p></div><div className="hero-art">🛍️</div></section>
        {message && <p className="message" role="status">{message}</p>}
        {error && <p className="error">{error} <button onClick={load}>Retry</button></p>}
        <div className="layout">
          <section className="products">
            <div className="section-title"><div><p className="eyebrow">OUR COLLECTION</p><h2>All products</h2></div><input aria-label="Search products" placeholder="Search products..." value={search} onChange={(e) => setSearch(e.target.value)}/></div>
            {loading ? <p className="empty">Loading products...</p> : filtered.length === 0 ? <p className="empty">No products found.</p> :
              <div className="grid">{filtered.map((p) => <article className="product" key={p.id}><div className="product-image">{p.category === "Electronics" ? "💻" : "🎒"}</div><small>{p.category}</small><h3>{p.name}</h3><strong>₹{p.price.toLocaleString("en-IN")}</strong><button onClick={() => addToCart(p.id)}>Add to cart +</button></article>)}</div>}
          </section>
          <aside className="cart"><div className="section-title"><h2>Your cart</h2><span>{cart.items.length} items</span></div>
            {cart.items.length === 0 ? <p className="empty">Your cart is empty.</p> : <>
              {cart.items.map((item) => <div className="cart-row" key={item.id}><div><b>{item.name}</b><small>₹{item.price.toLocaleString("en-IN")}</small></div><div className="qty"><button aria-label={`Decrease ${item.name}`} onClick={() => updateQuantity(item.id, item.quantity - 1)}>−</button><span>{item.quantity}</span><button aria-label={`Increase ${item.name}`} onClick={() => updateQuantity(item.id, item.quantity + 1)}>+</button></div></div>)}
              <div className="total"><span>Total</span><b>₹{cart.total.toLocaleString("en-IN")}</b></div>
              <button className="checkout" onClick={placeOrder}>Place order</button>
            </>}
          </aside>
        </div>
      </main>
      <footer>ShopSmart · Online Shopping Demo</footer>
    </div>
  );
}
