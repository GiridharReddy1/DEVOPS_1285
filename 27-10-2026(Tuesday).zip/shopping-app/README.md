# Online Shopping App – Integration Testing (Assignment 11.2.1)

## Project structure

- `frontend/` — React shopping UI with product listing, search, product details through product cards, cart quantity controls and checkout.
- `backend/` — Express APIs for products, cart and orders.
- `integration-tests/` — end-to-end API workflow tests using Jest and Axios.
- `.github/workflows/ci.yml` — GitHub Actions CI pipeline.

## Run locally

Open three terminals from the project root.

### Terminal 1: Backend

```bash
cd backend
npm install
npm start
```

Backend: `http://localhost:5000`

### Terminal 2: Frontend

```bash
cd frontend
npm install
npm run dev
```

Open the Vite URL printed in the terminal, usually `http://localhost:5173`.

### Terminal 3: Integration tests

Keep the backend running, then:

```bash
cd integration-tests
npm install
npm test
```

## API endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/products` | Retrieve all products |
| GET | `/api/products/:id` | Retrieve one product |
| POST | `/api/cart` | Add a product to cart |
| GET | `/api/cart` | View cart and total |
| PUT | `/api/cart/:id` | Update cart quantity |
| DELETE | `/api/cart/:id` | Remove product from cart |
| POST | `/api/orders` | Place an order |
| GET | `/api/orders` | View order history |

### Add to cart example

```json
{
  "productId": 101,
  "quantity": 1
}
```

### Update cart example

```json
{
  "quantity": 2
}
```

## Integration workflow tested

1. Retrieve products.
2. Select the Laptop (ID 101).
3. Add it to the cart.
4. Update its quantity to 2.
5. Verify total = ₹120,000.
6. Place the order.
7. Verify the order in order history.

## CI pipeline

On every push or pull request to `main`, GitHub Actions runs:

1. Backend unit tests.
2. Starts the backend service.
3. Waits for the API to become available.
4. Runs the complete API integration test workflow.
5. Builds the React frontend and uploads the build as an artifact.

The jobs use `needs` so a failed unit test or integration test stops the later stage.

## Push to GitHub

From the project root:

```bash
git init
git add .
git commit -m "Add shopping app integration testing and CI"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

Replace the URL with your own GitHub repository URL. Then open the repository's **Actions** tab to see the workflow run.

## Important note

This assignment demo stores products, cart and orders in server memory. The data resets when the backend restarts. The PDF lists PostgreSQL or MongoDB and a separate test database as advanced operations; those are not configured in this starter project.
